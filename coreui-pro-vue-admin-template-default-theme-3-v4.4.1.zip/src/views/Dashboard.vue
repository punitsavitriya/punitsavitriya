<template>
  <CRow>
    <CCol :xl="4">
      <CRow>
        <CCol :lg="12">
          <CCard class="mb-4">
            <CCardBody class="p-4">
              <CRow>
                <CCol>
                  <CCardTitle class="fs-4 fw-semibold">Sale</CCardTitle>
                  <CCardSubtitle class="fw-normal text-disabled">
                    January - July 2022
                  </CCardSubtitle>
                </CCol>
                <CCol class="text-end text-primary fs-4 fw-semibold"
                  >$613.200</CCol
                >
              </CRow>
            </CCardBody>
            <CChart
              type="line"
              class="mt-3"
              style="height: 150px"
              :data="{
                labels: [
                  'January',
                  'February',
                  'March',
                  'April',
                  'May',
                  'June',
                  'July',
                ],
                datasets: [
                  {
                    label: 'My First dataset',
                    backgroundColor: `rgba(${getStyle(
                      '--cui-primary-rgb',
                    )}, .1)`,
                    borderColor: getStyle('--cui-primary'),
                    borderWidth: 3,
                    data: [78, 81, 80, 45, 34, 22, 40],
                    fill: true,
                  },
                ],
              }"
              :options="{
                plugins: {
                  legend: {
                    display: false,
                  },
                },
                maintainAspectRatio: false,
                scales: {
                  x: {
                    display: false,
                  },
                  y: {
                    beginAtZero: true,
                    display: false,
                  },
                },
                elements: {
                  line: {
                    borderWidth: 2,
                    tension: 0.4,
                  },
                  point: {
                    radius: 0,
                    hitRadius: 10,
                    hoverRadius: 4,
                  },
                },
              }"
            />
          </CCard>
        </CCol>
        <CCol :lg="6">
          <CCard class="mb-4">
            <CCardBody>
              <div class="d-flex justify-content-between">
                <CCardTitle component="div" class="text-disabled"
                  >Customers</CCardTitle
                >
                <div class="bg-primary bg-opacity-25 text-primary p-2 rounded">
                  <CIcon icon="cil-people" size="xl" />
                </div>
              </div>
              <div class="fs-4 fw-semibold pb-3">44.725</div>
              <small class="text-danger">
                (-12.4% <CIcon icon="cil-arrow-bottom" />)
              </small>
            </CCardBody>
          </CCard>
        </CCol>
        <CCol :lg="6">
          <CCard class="mb-4">
            <CCardBody>
              <div class="d-flex justify-content-between">
                <CCardTitle component="div" class="text-disabled"
                  >Orders</CCardTitle
                >
                <div class="bg-primary bg-opacity-25 text-primary p-2 rounded">
                  <CIcon icon="cil-cart" size="xl" />
                </div>
              </div>
              <div class="fs-4 fw-semibold pb-3">385</div>
              <small class="text-success">
                (17.2% <CIcon icon="cil-arrow-top" />)
              </small>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </CCol>
    <CCol :xl="8">
      <CCard class="mb-4">
        <CCardBody class="p-4">
          <CCardTitle class="fs-4 fw-semibold">Traffic</CCardTitle>
          <CCardSubtitle class="fw-normal text-disabled">
            January 01, 2021 - December 31, 2021
          </CCardSubtitle>
          <CChart
            type="bar"
            style="height: 300px; margin-top: 40px"
            :data="{
              labels: [
                'Jan',
                'Feb',
                'Mar',
                'Apr',
                'May',
                'Jun',
                'Jul',
                'Aug',
                'Sep',
                'Oct',
                'Nov',
                'Dec',
              ],
              datasets: [
                {
                  label: 'Users',
                  backgroundColor: getStyle('--cui-primary'),
                  borderRadius: 6,
                  borderSkipped: false,
                  data: [
                    78, 81, 80, 45, 34, 12, 40, 85, 65, 23, 12, 98, 34, 84, 67,
                    82,
                  ],
                  barPercentage: 0.6,
                  categoryPercentage: 0.5,
                },
                {
                  label: 'New users',
                  backgroundColor: getStyle('--cui-gray-100'),
                  borderRadius: 6,
                  borderSkipped: false,
                  data: [
                    78, 81, 80, 45, 34, 12, 40, 85, 65, 23, 12, 98, 34, 84, 67,
                    82,
                  ],
                  barPercentage: 0.6,
                  categoryPercentage: 0.5,
                },
              ],
            }"
            :options="{
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false,
                },
              },
              scales: {
                x: {
                  grid: {
                    display: false,
                    drawBorder: false,
                    drawTicks: false,
                  },
                  ticks: {
                    color: getStyle('--cui-text-disabled'),
                    font: {
                      size: 14,
                    },
                    padding: 16,
                  },
                },
                y: {
                  grid: {
                    drawBorder: false,
                    borderDash: [2, 4],
                  },
                  gridLines: {
                    borderDash: [8, 4],
                    color: '#348632',
                  },
                  ticks: {
                    beginAtZero: true,
                    color: getStyle('--cui-text-disabled'),
                    font: {
                      size: 14,
                    },
                    maxTicksLimit: 5,
                    padding: 16,
                    stepSize: Math.ceil(100 / 4),
                  },
                },
              },
            }"
          />
        </CCardBody>
      </CCard>
    </CCol>
  </CRow>
  <CRow>
    <CCol :xl="9">
      <CCard class="mb-4">
        <CCardBody class="p-4">
          <CRow>
            <CCol>
              <CCardTitle class="fs-4 fw-semibold">Users</CCardTitle>
              <CCardSubtitle class="fw-normal text-disabled mb-4">
                1.232.150 registered users
              </CCardSubtitle>
            </CCol>
            <CCol xs="auto" class="ms-auto">
              <CButton color="secondary">
                <CIcon icon="cil-user-plus" class="me-2" />
                Add new user
              </CButton>
            </CCol>
          </CRow>
          <CTable align="middle" class="mb-0" hover responsive>
            <CTableHead class="fw-semibold text-disabled">
              <CTableRow>
                <CTableHeaderCell class="text-center">
                  <CIcon name="cil-people" />
                </CTableHeaderCell>
                <CTableHeaderCell>User</CTableHeaderCell>
                <CTableHeaderCell class="text-center">Country</CTableHeaderCell>
                <CTableHeaderCell>Usage</CTableHeaderCell>
                <CTableHeaderCell>Activity</CTableHeaderCell>
              </CTableRow>
            </CTableHead>
            <CTableBody>
              <CTableRow v-for="item in tableExample" :key="item.name">
                <CTableDataCell class="text-center">
                  <CAvatar
                    size="md"
                    :src="item.avatar.src"
                    :status="item.avatar.status"
                  />
                </CTableDataCell>
                <CTableDataCell>
                  <div>{{ item.user.name }}</div>
                  <div class="small text-disabled text-nowrap">
                    <span>{{ item.user.new ? 'New' : 'Recurring' }}</span> |
                    {{ item.user.registered }}
                  </div>
                </CTableDataCell>
                <CTableDataCell class="text-center">
                  <CIcon
                    size="xl"
                    :name="item.country.flag"
                    :title="item.country.name"
                  />
                </CTableDataCell>
                <CTableDataCell>
                  <div class="d-flex justify-content-between mb-1">
                    <div class="fw-semibold">{{ item.usage.value }}%</div>
                    <div class="small text-disabled ms-1 text-nowrap">
                      {{ item.usage.period }}
                    </div>
                  </div>
                  <CProgress
                    thin
                    :color="item.usage.color"
                    :value="item.usage.value"
                  />
                </CTableDataCell>
                <CTableDataCell>
                  <div class="small text-disabled">Last login</div>
                  <div class="fw-semibold text-nowrap">
                    {{ item.activity }}
                  </div>
                </CTableDataCell>
              </CTableRow>
            </CTableBody>
          </CTable>
        </CCardBody>
      </CCard>
    </CCol>
    <CCol :xl="3">
      <CRow>
        <CCol :md="4" :xl="12">
          <CWidgetStatsA class="mb-4" color="primary-gradient">
            <template #value
              >26K
              <span class="fs-6 fw-normal">
                (-12.4% <CIcon icon="cil-arrow-bottom" />)
              </span>
            </template>
            <template #title>Users</template>
            <template #action>
              <CDropdown placement="bottom-end">
                <CDropdownToggle
                  color="transparent"
                  class="p-0 text-white"
                  :caret="false"
                >
                  <CIcon
                    icon="cil-options"
                    class="text-high-emphasis-inverse"
                  />
                </CDropdownToggle>
                <CDropdownMenu>
                  <CDropdownItem href="#">Action</CDropdownItem>
                  <CDropdownItem href="#">Another action</CDropdownItem>
                  <CDropdownItem href="#">Something else here</CDropdownItem>
                </CDropdownMenu>
              </CDropdown>
            </template>
            <template #chart>
              <CChart
                type="line"
                class="mt-3 mx-3"
                style="height: 85px"
                :data="{
                  labels: [
                    'January',
                    'February',
                    'March',
                    'April',
                    'May',
                    'June',
                    'July',
                  ],
                  datasets: [
                    {
                      label: 'My First dataset',
                      backgroundColor: 'transparent',
                      borderColor: 'rgba(255,255,255,.55)',
                      pointBackgroundColor: getStyle('--cui-primary'),
                      data: [68, 59, 84, 84, 51, 55, 40],
                    },
                  ],
                }"
                :options="{
                  plugins: {
                    legend: {
                      display: false,
                    },
                  },
                  maintainAspectRatio: false,
                  scales: {
                    x: {
                      grid: {
                        display: false,
                        drawBorder: false,
                      },
                      ticks: {
                        display: false,
                      },
                    },
                    y: {
                      min: 30,
                      max: 89,
                      display: false,
                      grid: {
                        display: false,
                      },
                      ticks: {
                        display: false,
                      },
                    },
                  },
                  elements: {
                    line: {
                      borderWidth: 1,
                      tension: 0.4,
                    },
                    point: {
                      radius: 4,
                      hitRadius: 10,
                      hoverRadius: 4,
                    },
                  },
                }"
              />
            </template>
          </CWidgetStatsA>
        </CCol>
        <CCol :md="4" :xl="12">
          <CWidgetStatsA class="mb-4" color="warning-gradient">
            <template #value
              >2.49%
              <span class="fs-6 fw-normal">
                (84.7% <CIcon icon="cil-arrow-top" />)
              </span>
            </template>
            <template #title>Conversion Rate</template>
            <template #action>
              <CDropdown placement="bottom-end">
                <CDropdownToggle
                  color="transparent"
                  class="p-0 text-white"
                  :caret="false"
                >
                  <CIcon
                    icon="cil-options"
                    class="text-high-emphasis-inverse"
                  />
                </CDropdownToggle>
                <CDropdownMenu>
                  <CDropdownItem href="#">Action</CDropdownItem>
                  <CDropdownItem href="#">Another action</CDropdownItem>
                  <CDropdownItem href="#">Something else here</CDropdownItem>
                </CDropdownMenu>
              </CDropdown>
            </template>
            <template #chart>
              <CChart
                type="line"
                class="mt-3"
                style="height: 85px"
                :data="{
                  labels: [
                    'January',
                    'February',
                    'March',
                    'April',
                    'May',
                    'June',
                    'July',
                  ],
                  datasets: [
                    {
                      label: 'My First dataset',
                      backgroundColor: 'rgba(255,255,255,.2)',
                      borderColor: 'rgba(255,255,255,.55)',
                      data: [78, 81, 80, 45, 34, 12, 40],
                      fill: true,
                    },
                  ],
                }"
                :options="{
                  plugins: {
                    legend: {
                      display: false,
                    },
                  },
                  maintainAspectRatio: false,
                  scales: {
                    x: {
                      display: false,
                    },
                    y: {
                      display: false,
                    },
                  },
                  elements: {
                    line: {
                      borderWidth: 2,
                      tension: 0.4,
                    },
                    point: {
                      radius: 0,
                      hitRadius: 10,
                      hoverRadius: 4,
                    },
                  },
                }"
              />
            </template>
          </CWidgetStatsA>
        </CCol>
        <CCol :md="4" :xl="12">
          <CWidgetStatsA class="mb-4" color="danger-gradient">
            <template #value
              >44K
              <span class="fs-6 fw-normal">
                (-23.6% <CIcon icon="cil-arrow-bottom" />)
              </span>
            </template>
            <template #title>Sessions</template>
            <template #action>
              <CDropdown placement="bottom-end">
                <CDropdownToggle
                  color="transparent"
                  class="p-0 text-white"
                  :caret="false"
                >
                  <CIcon
                    icon="cil-options"
                    class="text-high-emphasis-inverse"
                  />
                </CDropdownToggle>
                <CDropdownMenu>
                  <CDropdownItem href="#">Action</CDropdownItem>
                  <CDropdownItem href="#">Another action</CDropdownItem>
                  <CDropdownItem href="#">Something else here</CDropdownItem>
                </CDropdownMenu>
              </CDropdown>
            </template>
            <template #chart>
              <CChart
                type="bar"
                class="mt-3 mx-3"
                style="height: 85px"
                :data="{
                  labels: [
                    'January',
                    'February',
                    'March',
                    'April',
                    'May',
                    'June',
                    'July',
                    'August',
                    'September',
                    'October',
                    'November',
                    'December',
                    'January',
                    'February',
                    'March',
                    'April',
                  ],
                  datasets: [
                    {
                      label: 'My First dataset',
                      backgroundColor: 'rgba(255,255,255,.2)',
                      borderColor: 'rgba(255,255,255,.55)',
                      data: [
                        78, 81, 80, 45, 34, 12, 40, 85, 65, 23, 12, 98, 34, 84,
                        67, 82,
                      ],
                      barPercentage: 0.6,
                    },
                  ],
                }"
                :options="{
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      display: false,
                    },
                  },
                  scales: {
                    x: {
                      grid: {
                        display: false,
                        drawTicks: false,
                      },
                      ticks: {
                        display: false,
                      },
                    },
                    y: {
                      grid: {
                        display: false,
                        drawBorder: false,
                        drawTicks: false,
                      },
                      ticks: {
                        display: false,
                      },
                    },
                  },
                }"
              />
            </template>
          </CWidgetStatsA>
        </CCol>
      </CRow>
    </CCol>
  </CRow>
  <div>
    <CRow>
      <CCol :md="12">
        <CCard class="mb-4">
          <CCardBody class="p-4">
            <CCardTitle class="fs-4 fw-semibold">Traffic</CCardTitle>
            <CCardSubtitle
              class="fw-normal text-disabled border-bottom mb-3 pb-4"
            >
              Last Week
            </CCardSubtitle>
            <CRow>
              <CCol :sm="12" :lg="6">
                <CRow>
                  <CCol :sm="6">
                    <div
                      class="border-start border-start-4 border-start-info py-1 px-3 mb-3"
                    >
                      <div class="text-disabled small">New Clients</div>
                      <div class="fs-5 fw-semibold">9,123</div>
                    </div>
                  </CCol>
                  <CCol :sm="6">
                    <div
                      class="border-start border-start-4 border-start-danger py-1 px-3 mb-3"
                    >
                      <div class="text-disabled small">Recurring Clients</div>
                      <div class="fs-5 fw-semibold">22,643</div>
                    </div>
                  </CCol>
                </CRow>
                <div class="border-top mb-4" />
                <div
                  v-for="item in progressGroupExample1"
                  :key="item.title"
                  class="progress-group mb-4"
                >
                  <div class="progress-group-prepend">
                    <span class="text-disabled small">{{ item.title }}</span>
                  </div>
                  <div class="progress-group-bars">
                    <CProgress
                      thin
                      color="info-gradient"
                      :value="item.value1"
                    />
                    <CProgress
                      thin
                      color="danger-gradient"
                      :value="item.value2"
                    />
                  </div>
                </div>
              </CCol>
              <CCol :sm="12" :lg="6">
                <CRow>
                  <CCol :sm="6">
                    <div
                      class="border-start border-start-4 border-start-warning py-1 px-3 mb-3"
                    >
                      <div class="text-disabled small">Pageviews</div>
                      <div class="fs-5 fw-semibold">78,623</div>
                    </div>
                  </CCol>
                  <CCol :sm="6">
                    <div
                      class="border-start border-start-4 border-start-success py-1 px-3 mb-3"
                    >
                      <div class="text-disabled small">Organic</div>
                      <div class="fs-5 fw-semibold">49,123</div>
                    </div>
                  </CCol>
                </CRow>
                <div class="border-top mb-4" />
                <div
                  v-for="item in progressGroupExample2"
                  :key="item.title"
                  class="progress-group"
                >
                  <div class="progress-group-header">
                    <CIcon :icon="item.icon" class="me-2" size="lg" />
                    <span class="title">{{ item.title }}</span>
                    <span class="ms-auto fw-semibold">{{ item.value }}%</span>
                  </div>
                  <div class="progress-group-bars">
                    <CProgress
                      thin
                      :value="item.value"
                      color="warning-gradient"
                    />
                  </div>
                </div>

                <div class="mb-5"></div>

                <div
                  v-for="item in progressGroupExample3"
                  :key="item.title"
                  class="progress-group"
                >
                  <div class="progress-group-header">
                    <CIcon :icon="item.icon" class="me-2" size="lg" />
                    <span class="title">Organic Search</span>
                    <span class="ms-auto fw-semibold">
                      {{ item.value }}
                      <span class="text-disabled small"
                        >({{ item.percent }}%)</span
                      >
                    </span>
                  </div>
                  <div class="progress-group-bars">
                    <CProgress
                      thin
                      :value="item.percent"
                      color="success-gradient"
                    />
                  </div>
                </div>
              </CCol>
            </CRow>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  </div>
</template>

<script>
import { CChart } from '@coreui/vue-chartjs'
import { getStyle, hexToRgba } from '@coreui/utils/src'

import avatar1 from '@/assets/images/avatars/1.jpg'
import avatar2 from '@/assets/images/avatars/2.jpg'
import avatar3 from '@/assets/images/avatars/3.jpg'
import avatar4 from '@/assets/images/avatars/4.jpg'
import avatar5 from '@/assets/images/avatars/5.jpg'
import avatar6 from '@/assets/images/avatars/6.jpg'

export default {
  name: 'Dashboard',
  components: {
    CChart,
  },
  setup() {
    const progressGroupExample1 = [
      { title: 'Monday', value1: 34, value2: 78 },
      { title: 'Tuesday', value1: 56, value2: 94 },
      { title: 'Wednesday', value1: 12, value2: 67 },
      { title: 'Thursday', value1: 43, value2: 91 },
      { title: 'Friday', value1: 22, value2: 73 },
      { title: 'Saturday', value1: 53, value2: 82 },
      { title: 'Sunday', value1: 9, value2: 69 },
    ]
    const progressGroupExample2 = [
      { title: 'Male', icon: 'cil-user', value: 53 },
      { title: 'Female', icon: 'cil-user-female', value: 43 },
    ]
    const progressGroupExample3 = [
      {
        title: 'Organic Search',
        icon: 'cib-google',
        percent: 56,
        value: '191,235',
      },
      { title: 'Facebook', icon: 'cib-facebook', percent: 15, value: '51,223' },
      { title: 'Twitter', icon: 'cib-twitter', percent: 11, value: '37,564' },
      { title: 'LinkedIn', icon: 'cib-linkedin', percent: 8, value: '27,319' },
    ]
    const tableExample = [
      {
        avatar: { src: avatar1, status: 'success' },
        user: {
          name: 'Yiorgos Avraamu',
          new: true,
          registered: 'Jan 1, 2021',
        },
        country: { name: 'USA', flag: 'cif-us' },
        usage: {
          value: 50,
          period: 'Jun 11, 2021 - Jul 10, 2021',
          color: 'success',
        },
        payment: { name: 'Mastercard', icon: 'cib-cc-mastercard' },
        activity: '10 sec ago',
      },
      {
        avatar: { src: avatar2, status: 'danger' },
        user: {
          name: 'Avram Tarasios',
          new: false,
          registered: 'Jan 1, 2021',
        },
        country: { name: 'Brazil', flag: 'cif-br' },
        usage: {
          value: 22,
          period: 'Jun 11, 2021 - Jul 10, 2021',
          color: 'info',
        },
        payment: { name: 'Visa', icon: 'cib-cc-visa' },
        activity: '5 minutes ago',
      },
      {
        avatar: { src: avatar3, status: 'warning' },
        user: { name: 'Quintin Ed', new: true, registered: 'Jan 1, 2021' },
        country: { name: 'India', flag: 'cif-in' },
        usage: {
          value: 74,
          period: 'Jun 11, 2021 - Jul 10, 2021',
          color: 'warning',
        },
        payment: { name: 'Stripe', icon: 'cib-cc-stripe' },
        activity: '1 hour ago',
      },
      {
        avatar: { src: avatar4, status: 'secondary' },
        user: { name: 'Enéas Kwadwo', new: true, registered: 'Jan 1, 2021' },
        country: { name: 'France', flag: 'cif-fr' },
        usage: {
          value: 98,
          period: 'Jun 11, 2021 - Jul 10, 2021',
          color: 'danger',
        },
        payment: { name: 'PayPal', icon: 'cib-cc-paypal' },
        activity: 'Last month',
      },
      {
        avatar: { src: avatar5, status: 'success' },
        user: {
          name: 'Agapetus Tadeáš',
          new: true,
          registered: 'Jan 1, 2021',
        },
        country: { name: 'Spain', flag: 'cif-es' },
        usage: {
          value: 22,
          period: 'Jun 11, 2021 - Jul 10, 2021',
          color: 'primary',
        },
        payment: { name: 'Google Wallet', icon: 'cib-cc-apple-pay' },
        activity: 'Last week',
      },
      {
        avatar: { src: avatar6, status: 'danger' },
        user: {
          name: 'Friderik Dávid',
          new: true,
          registered: 'Jan 1, 2021',
        },
        country: { name: 'Poland', flag: 'cif-pl' },
        usage: {
          value: 43,
          period: 'Jun 11, 2021 - Jul 10, 2021',
          color: 'success',
        },
        payment: { name: 'Amex', icon: 'cib-cc-amex' },
        activity: 'Last week',
      },
    ]

    return {
      getStyle,
      hexToRgba,
      tableExample,
      progressGroupExample1,
      progressGroupExample2,
      progressGroupExample3,
    }
  },
}
</script>
